#ifndef GIMLI_H
#define GIMLI_H

#include <stdint.h>

void gimli(uint32_t *state);

#endif
