#ifndef CPUCYCLES_H
#define CPUCYCLES_H

unsigned long long cpucycles(void);

#endif
