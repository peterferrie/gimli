#ifndef AVR_H
#define AVR_H

void avr_end();

#endif
