#ifndef FAIL_H
#define FAIL_H

void fail(const char *error);

#endif
