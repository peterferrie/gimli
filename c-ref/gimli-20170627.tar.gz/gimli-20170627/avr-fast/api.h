#define gimli avr_gimli

extern void gimli(unsigned char *);
