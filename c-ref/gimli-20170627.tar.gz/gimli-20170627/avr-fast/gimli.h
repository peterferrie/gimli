#ifndef GIMLI_H
#define GIMLI_H

#define gimli avr_gimli

//Assembler Routines
extern void gimli(unsigned char* s);

#endif