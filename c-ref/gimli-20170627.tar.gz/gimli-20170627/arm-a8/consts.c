#include <stdint.h>

uint32_t __attribute__ ((aligned (16))) gimli_rconsts[24] = {
  0x9e377918,0,0,0,
  0x9e377914,0,0,0,
  0x9e377910,0,0,0,
  0x9e37790c,0,0,0,
  0x9e377908,0,0,0,
  0x9e377904,0,0,0
};

unsigned char __attribute__ ((aligned (8))) gimli_rot8[8] = {
  1,2,3,0,5,6,7,4
};
