#include <x86intrin.h>
#include <stdint.h>

void gimli(uint32_t *state);